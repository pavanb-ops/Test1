package com.rera.scheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComReraSchedulerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
