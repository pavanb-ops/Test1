package com.rera.scheduler.util;

public class CommonConstants {
	private CommonConstants() {}
//
//	public static final String USER_HAVE_NO_ADMIN_ROLE = "user does not have admin role";
//	public static final String USER_ACCOUNT_EXPIRED = "Your account has expired. Please contact system administrator to extend the user end date from profile management.";
//	public static final String SUCCESS = "SUCCESS";
//	public static final String ERROR = "ERROR";
//	public static final String FAILURE = "FAILURE";
//	public static final String SUCCESS_STATUS = "1";
//	public static final String ERROR_STATUS = "0";
//	public static final String FAILURE_STATUS = "2";
//	public static final String NO_RECORDS_FOUND_STATUS = "NO_RECORDS_FOUND";
//	public static final String NO_RECORDS_FOUND_MSG = "No records found";
//	public static final String response_code ="1000";
//	public static final  String response_msg ="able to fetch the data records";


}
