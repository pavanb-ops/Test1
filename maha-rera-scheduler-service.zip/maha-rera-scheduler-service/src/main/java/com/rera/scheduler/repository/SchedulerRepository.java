package com.rera.scheduler.repository;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.rera.scheduler.model.*;

@Component
public interface SchedulerRepository {

	public List<EmailSchedulerRequestsData> emailSchedulerTwentyFourHoursBefore()throws Exception;
	

}
