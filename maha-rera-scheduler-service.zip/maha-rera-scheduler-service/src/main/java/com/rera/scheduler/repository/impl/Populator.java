package com.rera.scheduler.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;

import com.rera.scheduler.model.EmailSchedulerRequestsData;

public interface Populator {

		default EmailSchedulerRequestsData populateEmailSchedulerResponseData(ResultSet resultSet)
				throws SQLException {
			ResultSetPopulator<EmailSchedulerRequestsData> resultSetPopulator = rs -> {
				EmailSchedulerRequestsData data = new EmailSchedulerRequestsData();

				String csvString = rs.getString("");
				data.setTo(convertCSVtoStringArray(csvString));

				data.setTemplateName(rs.getString("COMPLAINT_HEARING_SCHEDULE_CAUSELIST_GENERATE"));
				
				List<String> list = new ArrayList<>();
				list.add(rs.getString("Complaint_Registration_No"));
				list.add(rs.getString("RERA_Registration_Number"));
				list.add(rs.getString("Date_Of_Hearing"));
				list.add(rs.getString("Time_Of_Hearing"));
				list.add(rs.getString("Hearing_Type_Stage"));
				String rsLink = rs.getString("Event_Join_Url");
				String meetLink = "<a href = "+rsLink+"> Link </a>";
				list.add(meetLink);
				data.setParams(list);
				
				List<String> list2 = new ArrayList<>();
				list.add(rs.getString("Complaint_Registration_No"));
				list.add(rs.getString("RERA_Registration_Number"));
				data.setSubjectParams(list2);
				
				return data;
			};
			return resultSetPopulator.populateObject(resultSet);

		}
		
		default String[] convertCSVtoStringArray(String csvString) {
			String[] array = Arrays.stream(csvString.split(","))
   	    		 .map(String::trim)
                    .toArray(String[]::new);
			return array;
		}
		
		
		
}

		
		
	
