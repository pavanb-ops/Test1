package com.rera.scheduler.commonmodel;

public class DBConfigModel {
	private String url;
	private String user;
	private String password;
	private Integer maxpoolsize;
	private Integer minPoolSize;
	private Long maxLifeTime;
	private Long idleTimeout;
	
	
	public Long getIdleTimeout() {
		return idleTimeout;
	}
	public void setIdleTimeout(Long idleTimeout) {
		this.idleTimeout = idleTimeout;
	}
	public Long getMaxLifeTime() {
		return maxLifeTime;
	}
	public void setMaxLifeTime(Long maxLifeTime) {
		this.maxLifeTime = maxLifeTime;
	}
	public Integer getMinPoolSize() {
		return minPoolSize;
	}
	public void setMinPoolSize(Integer minPoolSize) {
		this.minPoolSize = minPoolSize;
	}
	public Integer getMaxpoolsize() {
		return maxpoolsize;
	}
	public void setMaxpoolsize(Integer maxpoolsize) {
		this.maxpoolsize = maxpoolsize;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
