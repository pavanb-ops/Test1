package com.rera.scheduler.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.rera.scheduler.service.BatchService;
import com.rera.scheduler.service.SchedulerService;

@Service
public class BatchServiceImpl implements BatchService {
    private static final Logger logger = LoggerFactory.getLogger(BatchServiceImpl.class);
    private final SchedulerService schedulerService;
    public BatchServiceImpl(SchedulerService schedulerService){this.schedulerService=schedulerService;}

    @Override
//    @Scheduled(cron = "${interval-in-cron}")
    public void runBatchJob() {
        logger.info("Running batch job started...");
        try {
//            schedulerService.emailSchedulerTwentyFourHoursBefore();
            logger.info("Running batch job completed successfully.");
        } catch (Exception e) {
            logger.error("Error occurred while running batch job: {}", e.getMessage());
            e.printStackTrace();
        }

    }
}
