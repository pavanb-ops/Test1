package com.rera.scheduler.service.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.rera.scheduler.dao.SchedulerDAO;
import com.rera.scheduler.model.EmailSchedulerRequest;
import com.rera.scheduler.model.EmailSchedulerRequestsData;
import com.rera.scheduler.model.SchedulerServiceResponse;
import com.rera.scheduler.service.IntegrationApiService;
import com.rera.scheduler.service.SchedulerService;

@Service
public class SchedulerServiceImpl implements SchedulerService {

	private static final Logger logger = LoggerFactory.getLogger(SchedulerServiceImpl.class);

	@Autowired
	SchedulerDAO schedulerDAO;
	
	@Autowired
	IntegrationApiService integrationApiService;

	@Override
	public SchedulerServiceResponse emailSchedulerTwentyFourHoursBefore() {
		logger.info("Start Method " + "Email Scheduler Twenty Four Hours Before");
		SchedulerServiceResponse responses = new SchedulerServiceResponse();
		try {
			List<EmailSchedulerRequestsData> detailsList = schedulerDAO
					.emailSchedulerTwentyFourHoursBefore();
			
			for(EmailSchedulerRequestsData request: detailsList) {
				ResponseEntity<String> req = integrationApiService.sendEmail(request);	
			}
			if (detailsList != null && !detailsList.isEmpty()) {
				responses.setResponseCode(1000);
				responses.setResponseMessage("Teams link sent over mail suceesfully....");
				responses.setTotalCount(detailsList.size());
				responses.setItems(detailsList);
			} else {
				responses.setResponseCode(1001);
				responses.setResponseMessage("Unable to find records");
				responses.setTotalCount(0);
				responses.setItems(detailsList);
			}
		}
		catch (Exception e) {
			responses.setResponseCode(1001);
			responses.setResponseMessage("Unable to find records");
			responses.setTotalCount(0);
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String stackTrace = sw.toString();
			logger.error("Exception - " + stackTrace);
		}
		logger.info("Exit Method " +"Email Scheduler Twenty Four Hours Before");
		return responses;
	}
	
	
	

}
