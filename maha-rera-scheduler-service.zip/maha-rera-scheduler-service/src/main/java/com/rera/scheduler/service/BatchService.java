package com.rera.scheduler.service;

public interface BatchService {
    void runBatchJob();
}
