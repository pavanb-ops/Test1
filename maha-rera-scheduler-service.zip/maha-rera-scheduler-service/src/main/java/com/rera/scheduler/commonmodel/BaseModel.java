package com.rera.scheduler.commonmodel;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer createdBy;
	private Timestamp createdDate;
	private Integer updatedBy;
	private Timestamp updatedDate;
	private Integer isActive;


}
