package com.rera.scheduler.repository.impl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.springframework.jdbc.core.SqlParameter;

import com.rera.scheduler.model.EmailSchedulerRequest;



/**
 * @author pavan-vm
 *
 */
public interface ParameterList {
	
	
	public default void setParametersEmailSchedulerBeforeTwentyFourHrsRequest(EmailSchedulerRequest request, int i,
			CallableStatement callableStatement) throws SQLException {// Assuming `callableStatement` is your CallableStatement object and `request` is your data object.
		
		
		
		if (request.getTemplateName()!=null && !request.getTemplateName().isEmpty()) {
			callableStatement.setString(i++, request.getTemplateName());
		} else {
			callableStatement.setNull(i++, java.sql.Types.NULL);
	    }
		
		if (request.getComplaintNo()!=null && !request.getComplaintNo().isEmpty()) {
			callableStatement.setString(i++, request.getComplaintNo());
		} else {
			callableStatement.setNull(i++, java.sql.Types.NULL);
	    }
		
		if (request.getProjectRegNo()!=null && !request.getProjectRegNo().isEmpty()) {
			callableStatement.setString(i++, request.getProjectRegNo());
		} else {
			callableStatement.setNull(i++, java.sql.Types.NULL);
	    }
		
		if (request.getDateOfHearing()!=null && !request.getDateOfHearing().isEmpty()) {
			callableStatement.setString(i++, request.getDateOfHearing());
		} else {
			callableStatement.setNull(i++, java.sql.Types.NULL);
	    }
		
		if (request.getTimeOfHearing()!=null && !request.getTimeOfHearing().isEmpty()) {
			callableStatement.setString(i++, request.getTimeOfHearing());
		} else {
			callableStatement.setNull(i++, java.sql.Types.NULL);
	    }
		
		if (request.getHearingStageType()!=null && !request.getHearingStageType().isEmpty()) {
			callableStatement.setString(i++, request.getHearingStageType());
		} else {
			callableStatement.setNull(i++, java.sql.Types.NULL);
	    }
		
		if (request.getMeetingLink()!=null && !request.getMeetingLink().isEmpty()) {
			callableStatement.setString(i++, request.getMeetingLink());
		} else {
			callableStatement.setNull(i++, java.sql.Types.NULL);
	    }
		
	}
}
