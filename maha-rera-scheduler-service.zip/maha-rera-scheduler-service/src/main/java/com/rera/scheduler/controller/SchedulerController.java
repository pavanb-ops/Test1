package com.rera.scheduler.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rera.scheduler.model.EmailSchedulerRequest;
import com.rera.scheduler.model.SchedulerServiceResponse;
import com.rera.scheduler.service.SchedulerService;
@RestController
@RequestMapping("/EmailScheduler")
public class SchedulerController {
//
//	private final SchedulerService schedulerService;
//
//	public SchedulerController(SchedulerService schedulerService) {
//		this.schedulerService = schedulerService;
//	}
//	
//	@PostMapping(path = "/emailScheduleTwentyFourHrsBefore")
//	public SchedulerServiceResponse emailSchedulerTwentyFourHoursBefore(
//			@Valid @RequestBody EmailSchedulerRequest emailSchedulerRequest) {
//		return schedulerService.emailSchedulerTwentyFourHoursBefore(emailSchedulerRequest);
//
//	}
}
