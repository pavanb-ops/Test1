package com.rera.scheduler.service.impl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.rera.scheduler.model.EmailSchedulerRequestsData;
import com.rera.scheduler.service.IntegrationApiService;


@Service
public class IntegrationApiServiceImpl implements IntegrationApiService {

	private static final Logger logger = LoggerFactory.getLogger(IntegrationApiServiceImpl.class);

	private final RestTemplate restTemplate;
	
	String authToken = " ";

    public IntegrationApiServiceImpl(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Value("${integration.sendEmail}")
	String sendEmail;
	
    @Override
    public ResponseEntity<String> sendEmail(EmailSchedulerRequestsData emailRequest) {
		logger.info("Start Method " + "sendEmail");
		ResponseEntity<String> response;
		try {
			Gson gson = new Gson();
			String gsonObject = gson.toJson(emailRequest);
			LinkedMultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
			map.add("request", gsonObject);
			
			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", "Bearer " + authToken); 
			headers.setContentType(MediaType.MULTIPART_FORM_DATA);
			HttpEntity<?> requestEntity = new HttpEntity<>(map,headers);
//			restTemplate.postForObject(urlSendEmail, requestEntity,
//					String.class);
			try {
				response =  restTemplate.exchange(sendEmail, HttpMethod.POST, requestEntity, String.class);
				logger.info("Exit Method " + "sendEmail");
				System.out.println("Response status code value : "+response.getStatusCode()+"  Response Body : "+response.getBody());
				return response;
			}catch(Exception e) {
				e.printStackTrace();
				return null;
			}						
		}
		catch(Exception e) {
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			String stackTrace = sw.toString();
			logger.error("Exception - " + stackTrace);
		}
		
		return null;	
	}
	
	

	
}
