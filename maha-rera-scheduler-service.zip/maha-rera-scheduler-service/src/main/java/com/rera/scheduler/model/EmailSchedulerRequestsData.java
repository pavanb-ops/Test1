package com.rera.scheduler.model;

import java.util.Date;
import java.util.List;

import javax.annotation.Nullable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EmailSchedulerRequestsData {
	
	@JsonProperty("to")
	private String[] to;
	
	@JsonProperty("cc")
	@Nullable
	private String[] cc;
	
	@JsonProperty("templateName")
	private String templateName;

	@JsonProperty("params")
	List<String> params;
	
	@JsonProperty("subjectParams")
	List<String> subjectParams;
	

//	@JsonProperty("SrNo")
//	private int srNo;
//
//	@JsonProperty("emails")
//	private List<String> emails;
//
//	@JsonProperty("templateName")
//	private String templateName;
//	
//	@JsonProperty("complaintNo")
//	private String complaintNo;
//	
//	@JsonProperty("projectRegNo")
//	private String projectRegNo;
//	
//	@JsonProperty("dateOfHearing")	
//	private String dateOfHearing;
//	
//	@JsonProperty("timeOfHearing")
//	private String timeOfHearing;
//	
//	@JsonProperty("hearingStageType")
//	private String hearingStageType;
//	
//	@JsonProperty("meetingLink")
//	private String meetingLink;	
	
}
