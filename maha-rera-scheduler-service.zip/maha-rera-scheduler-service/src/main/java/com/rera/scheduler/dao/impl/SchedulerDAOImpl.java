package com.rera.scheduler.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;


import com.rera.scheduler.dao.SchedulerDAO;
import com.rera.scheduler.model.EmailSchedulerRequest;
import com.rera.scheduler.model.EmailSchedulerRequestsData;
import com.rera.scheduler.repository.SchedulerRepository;

@Component
public class SchedulerDAOImpl implements SchedulerDAO {
	
	private final SchedulerRepository schedulerRepository;

	public SchedulerDAOImpl(SchedulerRepository schedulerRepository) {
		this.schedulerRepository = schedulerRepository;
	}

	@Override
	public List<EmailSchedulerRequestsData> emailSchedulerTwentyFourHoursBefore() throws Exception {
		return schedulerRepository
				.emailSchedulerTwentyFourHoursBefore();
	}

	

}

