package com.rera.scheduler.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.rera.scheduler.model.EmailSchedulerRequestsData;

@Component
public interface IntegrationApiService {

	ResponseEntity<String> sendEmail(EmailSchedulerRequestsData emailRequest);

}
