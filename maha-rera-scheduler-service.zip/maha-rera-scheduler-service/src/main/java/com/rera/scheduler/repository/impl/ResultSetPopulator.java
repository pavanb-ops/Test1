package com.rera.scheduler.repository.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

@FunctionalInterface
public interface ResultSetPopulator<T> {
	 T populateObject(ResultSet rs) throws SQLException;

}
