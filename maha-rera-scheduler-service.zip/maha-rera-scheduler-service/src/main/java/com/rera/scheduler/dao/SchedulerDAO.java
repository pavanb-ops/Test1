package com.rera.scheduler.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.stereotype.Component;


import com.rera.scheduler.model.*;

@Component
public interface SchedulerDAO {

	public List<EmailSchedulerRequestsData> emailSchedulerTwentyFourHoursBefore() throws Exception;
	
	
}
