package com.rera.scheduler;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.sql.DataSource;

//import org.keycloak.KeycloakPrincipal;
//import org.keycloak.KeycloakSecurityContext;
//import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
//import org.keycloak.representations.AccessToken;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.rera.scheduler.commonmodel.DBConfigModel;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DbConfig {
		@Primary
		@Bean(name = "dbone",destroyMethod = "close")
		//@ConfigurationProperties(prefix = "spring.datasource.userone")
		public DataSource dataSourceOne() {
			//DBConfigModel model = DbConfig.loaddbPropeties("dbone.url", "dbone.user", "dbone.password","dbone.maxpoolsize","dbone.minpoolsize","dbone.maxlifetime","dbone.idletimeout");
			HikariConfig hikariConfig = new HikariConfig();
		    hikariConfig.setDriverClassName("com.mysql.jdbc.Driver");

		    String minPoolSize  = System.getenv("MYSQL_MINPOOLSIZE");
                    int minPoolSizeValue = Integer.parseInt(minPoolSize);

                    String maxPoolSize  = System.getenv("MYSQL_MAXPOOLSIZE");
                    int maxPoolSizeValue = Integer.parseInt(maxPoolSize);

                    String maxlifetime  = System.getenv("MYSQL_MAXLIFETIME");
                    int maxlifetimevalue = Integer.parseInt(maxlifetime);

                    String idletimeout  = System.getenv("MYSQL_IDLETIMEOUT");
                    int idletimeoutValue = Integer.parseInt(idletimeout);

		   
		    //System.out.println("==========================>"+model.getUrl());
		   /* hikariConfig.setJdbcUrl(model.getUrl());
		    hikariConfig.setUsername(model.getUser());
		    hikariConfig.setPassword(model.getPassword());
		    
		    hikariConfig.setMinimumIdle(model.getMinPoolSize());
		    hikariConfig.setMaximumPoolSize(model.getMaxpoolsize());
		   // hikariConfig.setMaxLifetime(1000);
		    hikariConfig.setMaxLifetime(model.getMaxLifeTime());
		    hikariConfig.setIdleTimeout(model.getIdleTimeout());*/

		    hikariConfig.setJdbcUrl(System.getenv("MYSQL_URL"));
                    hikariConfig.setUsername(System.getenv("MYSQL_USERNAME"));
                    hikariConfig.setPassword(System.getenv("MYSQL_PASS"));
                    
                    hikariConfig.setMinimumIdle(minPoolSizeValue);
                    hikariConfig.setMaximumPoolSize(maxPoolSizeValue);
                 // hikariConfig.setMaxLifetime(1000);
                    hikariConfig.setMaxLifetime(maxlifetimevalue);
                    //hikariConfig.setIdleTimeout(10000);
                    hikariConfig.setIdleTimeout(idletimeoutValue);
		    
		    
		    hikariConfig.setConnectionTestQuery("SELECT 1");
		    hikariConfig.setPoolName("springHikariCPAutoCommitFalse");
		    hikariConfig.setAutoCommit(false);
		    //hikariConfig.setRegisterMbeans(true);

		    hikariConfig.addDataSourceProperty("dataSource.cachePrepStmts", "true");
		    hikariConfig.addDataSourceProperty("dataSource.prepStmtCacheSize", "250");
		    hikariConfig.addDataSourceProperty("dataSource.prepStmtCacheSqlLimit", "2048");
		    hikariConfig.addDataSourceProperty("dataSource.useServerPrepStmts", "true");

		    HikariDataSource dataSource = new HikariDataSource(hikariConfig);
		    System.out.println("Datasource Created Sucessfully...");
		    return dataSource;
		}
		
		@Primary
		@Bean(name = "jdbcTemplateAutoCommitFalse")
		public JdbcTemplate jdbcTemplate1(@Qualifier("dbone") DataSource ds) {
			return new JdbcTemplate(ds);
		}
		
		@Bean(name = "dbtwo",destroyMethod = "close")
		//@ConfigurationProperties(prefix = "spring.datasource.usertwo")
		public DataSource dataSourceTwo() {
			//DBConfigModel model = DbConfig.loaddbPropeties("dbtwo.url", "dbtwo.user", "dbtwo.password","dbtwo.maxpoolsize","dbtwo.minpoolsize","dbtwo.maxlifetime","dbtwo.idletimeout");
					HikariConfig hikariConfig = new HikariConfig();
				    hikariConfig.setDriverClassName("com.mysql.jdbc.Driver");
			            String minPoolSize  = System.getenv("MYSQL_MINPOOLSIZE");
		                    int minPoolSizeValue = Integer.parseInt(minPoolSize);
		
		                    String maxPoolSize  = System.getenv("MYSQL_MAXPOOLSIZE");
		                    int maxPoolSizeValue = Integer.parseInt(maxPoolSize);
		
		                    String maxlifetime  = System.getenv("MYSQL_MAXLIFETIME");
		                    int maxlifetimevalue = Integer.parseInt(maxlifetime);
		
		                    String idletimeout  = System.getenv("MYSQL_IDLETIMEOUT");
		                    int idletimeoutValue = Integer.parseInt(idletimeout);
				   
				   // System.out.println("==========================>"+model.getUrl());
				   /* hikariConfig.setJdbcUrl(model.getUrl());
				    hikariConfig.setUsername(model.getUser());
				    hikariConfig.setPassword(model.getPassword());
				    
				    hikariConfig.setMinimumIdle(model.getMinPoolSize());
				    hikariConfig.setMaximumPoolSize(model.getMaxpoolsize());
				 // hikariConfig.setMaxLifetime(1000);
				    hikariConfig.setMaxLifetime(model.getMaxLifeTime());
				    //hikariConfig.setIdleTimeout(10000);
				    hikariConfig.setIdleTimeout(model.getIdleTimeout());*/
			
			            hikariConfig.setJdbcUrl(System.getenv("MYSQL_URL"));
		                    hikariConfig.setUsername(System.getenv("MYSQL_USERNAME"));
		                    hikariConfig.setPassword(System.getenv("MYSQL_PASS"));
		                    
		                    hikariConfig.setMinimumIdle(minPoolSizeValue);
		                    hikariConfig.setMaximumPoolSize(maxPoolSizeValue);
		                 // hikariConfig.setMaxLifetime(1000);
		                    hikariConfig.setMaxLifetime(maxlifetimevalue);
		                    //hikariConfig.setIdleTimeout(10000);
		                    hikariConfig.setIdleTimeout(idletimeoutValue);
			
				    hikariConfig.setConnectionTestQuery("SELECT 1");
				    hikariConfig.setPoolName("springHikariCPAutoCommitTrue");
				    hikariConfig.setAutoCommit(true);
				    //hikariConfig.setRegisterMbeans(true);

				    hikariConfig.addDataSourceProperty("dataSource.cachePrepStmts", "true");
				    hikariConfig.addDataSourceProperty("dataSource.prepStmtCacheSize", "250");
				    hikariConfig.addDataSourceProperty("dataSource.prepStmtCacheSqlLimit", "2048");
				    hikariConfig.addDataSourceProperty("dataSource.useServerPrepStmts", "true");

				    HikariDataSource dataSource = new HikariDataSource(hikariConfig);
				    System.out.println("Datasource Created Sucessfully...");
				    return dataSource;
		}
		
		@Bean(name = "jdbcTemplateAutoCommitTrue")
		public JdbcTemplate jdbcTemplate2(@Qualifier("dbtwo") DataSource ds) {
			return new JdbcTemplate(ds);
		}
		
		public static DBConfigModel loaddbPropeties(String url,String user,String password,String maxpoolsize,String minpoolsize,String maxlifetime,String idletimeout) {

        	InputStream input = null;
			try {				
				input = new FileInputStream("C://opt/config/maha-rera-scheduler-service-dbconfig.properties");				
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

            Properties prop = new Properties();

            // load a properties file
            try {
				prop.load(input);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

            // get the property value and print it out
           
            DBConfigModel model = new DBConfigModel();
            model.setUrl(prop.getProperty(url));
            model.setUser(prop.getProperty(user));
            model.setPassword(prop.getProperty(password));
            model.setMaxpoolsize(Integer.parseInt(prop.getProperty(maxpoolsize)));
            model.setMinPoolSize(Integer.parseInt(prop.getProperty(minpoolsize)));
            model.setMaxLifeTime(Long.parseLong(prop.getProperty(maxlifetime)));
            model.setIdleTimeout(Long.parseLong(prop.getProperty(idletimeout)));
            
            return model;
        

    }

}


				