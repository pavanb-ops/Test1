package com.rera.scheduler.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.rera.scheduler.model.EmailSchedulerRequest;
import com.rera.scheduler.model.SchedulerServiceResponse;


@Component
public interface SchedulerService {
	
	SchedulerServiceResponse emailSchedulerTwentyFourHoursBefore();
	
}
