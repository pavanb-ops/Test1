package com.rera.scheduler.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EmailSchedulerRequest {


	@JsonProperty("SrNo")
	private int srNo;

	@JsonProperty("templateName")
	private String templateName;
	
	@JsonProperty("complaintNo")
	private String complaintNo;
	
	@JsonProperty("projectRegNo")
	private String projectRegNo;
	
	@JsonProperty("dateOfHearing")	
	private String dateOfHearing;
	
	@JsonProperty("timeOfHearing")
	private String timeOfHearing;
	
	@JsonProperty("hearingStageType")
	private String hearingStageType;
	
	@JsonProperty("meetingLink")
	private String meetingLink;	
	
}
