package com.rera.scheduler.util;

public class SqlConstants {

//	public static final String CORAM_DETAILS_MASTER_ASYNC= "SELECT Bench_id,Bench_Name  \r\n"
//			+ "FROM complaint.m_bench_master where Is_Active=1 ";
	
	public static final String COMPLAINT_HEARING_SCHEDULED_CAUSELIST="complaint.usp_get_hearing_notifications_list";
	
}

