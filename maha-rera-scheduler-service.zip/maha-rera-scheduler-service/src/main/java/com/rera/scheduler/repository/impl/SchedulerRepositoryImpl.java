package com.rera.scheduler.repository.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.lang3.StringUtils;
import javax.sql.DataSource;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.rera.scheduler.model.EmailSchedulerRequest;
import com.rera.scheduler.model.EmailSchedulerRequestsData;
import com.rera.scheduler.repository.SchedulerRepository;
import com.rera.scheduler.util.SqlConstants;

@Repository
public class SchedulerRepositoryImpl implements SchedulerRepository, ParameterList , Populator{

	@Autowired
	@Qualifier("jdbcTemplateAutoCommitTrue")
	private JdbcTemplate jdbcTemplate;

	@Autowired
	@Qualifier("dbone")
	private DataSource ds;

	@Autowired
	@Qualifier("dbtwo")
	private DataSource dsAutommitTrue;

	@Value("${projectViewUrl}")
	String projectViewUrl;

	@Value("${agentViewUrl}")
	String agentViewUrl;

	/**
	 * @param rs
	 * @param callableStatement
	 * @param connection
	 * @throws SQLException
	 */
	private void releaseResources(ResultSet rs, CallableStatement callableStatement, Connection connection)
			throws SQLException {
		if (null != rs) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (null != callableStatement) {
			try {
				callableStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (null != connection) {
			DataSourceUtils.releaseConnection(connection, this.ds);
		}
	}


	@Override
	public List<EmailSchedulerRequestsData> emailSchedulerTwentyFourHoursBefore() throws Exception {
		List<EmailSchedulerRequestsData> data = new ArrayList<EmailSchedulerRequestsData>();
		EmailSchedulerRequestsData details = null;
		final String SQL = "call " + SqlConstants.COMPLAINT_HEARING_SCHEDULED_CAUSELIST;
		int i = 1;
		CallableStatementCreator callableStatementCreator = con -> {
			CallableStatement cs = con.prepareCall(SQL);
//			setParametersEmailSchedulerBeforeTwentyFourHrsRequest(emailSchedulerRequest, i, cs);
			System.out.println(cs);
			return cs;
		};
		try (Connection connection = DataSourceUtils.getConnection(this.ds);
			 CallableStatement callableStatement = callableStatementCreator.createCallableStatement(connection);
			 ResultSet rs = callableStatement.executeQuery()) {
			if (rs != null ) {
				while (rs.next()) {
					details = populateEmailSchedulerResponseData(rs);
					if (details != null) {
						data.add(details);
					}
				}
			}
			connection.commit();
		}

		return data;
	}

}
