package com.rera.scheduler.model;

import lombok.Data;

@Data
public class SchedulerServiceResponse {
	private int responseCode;
	private String responseMessage;
	private int totalCount;
	private Object items;
}
